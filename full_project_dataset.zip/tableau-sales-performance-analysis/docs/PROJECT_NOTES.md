# Project Notes and Portfolio Checklist

## Suggested business narrative

This dashboard gives a consolidated view of sales performance. It starts with revenue and quantity KPIs, compares revenue across markets, shows monthly movement, and then focuses on the top customers and products. Year and month filters support time-based exploration.

## Before sharing publicly

- [ ] Confirm the market quantity worksheet uses `SUM(sales_qty)` and displays unit counts, not currency.
- [ ] Confirm revenue currency consistency or document the conversion method.
- [ ] Test every year and month filter and verify that all relevant charts respond.
- [ ] Confirm Top 5 customer and product rankings use the intended metric (revenue or quantity).
- [ ] Check titles, number formats, abbreviations, and spelling.
- [ ] Open the packaged workbook on another machine or Tableau profile, if possible.
- [ ] Replace this preview image if the dashboard is updated.

## Suggested GitHub repository description

Interactive Tableau sales dashboard analyzing revenue by market and month, with KPI summaries and top-customer and top-product analysis.

## Suggested GitHub topics

`tableau` `data-analytics` `sales-analysis` `dashboard` `data-visualization` `business-intelligence`

## Suggested LinkedIn project caption

Built an interactive Sales Performance Dashboard in Tableau to explore revenue trends, compare market performance, and identify top customers and products. The dashboard combines KPI reporting with year/month filtering to support faster sales analysis and business storytelling.
