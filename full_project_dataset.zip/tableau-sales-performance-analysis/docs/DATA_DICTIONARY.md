# Data Dictionary

The repository includes five CSV files. Field names below are taken from the supplied files.

## transactions.csv

| Field | Description |
|---|---|
| `product_code` | Product identifier for the transaction. |
| `customer_code` | Customer identifier. |
| `market_code` | Market identifier. |
| `order_date` | Date of the transaction/order. |
| `sales_qty` | Quantity sold. |
| `sales_amount` | Recorded sales amount. |
| `currency` | Currency code associated with the recorded sales amount. |

## customers.csv

| Field | Description |
|---|---|
| `customer_code` | Customer identifier. |
| `custmer_name` | Customer name (source field spelling retained). |
| `customer_type` | Customer classification/type. |

## dates.csv

| Field | Description |
|---|---|
| `date` | Calendar date. |
| `cy_date` | Calendar-year date attribute from the source. |
| `year` | Year. |
| `month_name` | Month name. |
| `date_yy_mmm` | Year/month display attribute. |

## markets.csv

| Field | Description |
|---|---|
| `markets_code` | Market identifier. |
| `markets_name` | Market name. |
| `zone` | Geographic zone. |

## products.csv

| Field | Description |
|---|---|
| `product_code` | Product identifier. |
| `product_type` | Product category/type. |

## Data handling note

The source transaction data includes a currency field. Revenue aggregation is meaningful across rows only after confirming that amounts share a currency or have been converted using a documented exchange-rate approach. Do not assume all amounts are in one currency.
